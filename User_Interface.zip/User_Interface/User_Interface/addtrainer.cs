﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace User_Interface
{
    public partial class addtrainer : Form
    {
        public addtrainer()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;"))
            {
                conn.Open();
                string query = "SELECT username, status FROM Trainer WHERE status = 'pending'";
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button2_Click(object sender, EventArgs e) //approve
        {
            string username = textBox1.Text;

            if (!string.IsNullOrEmpty(username))
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;"))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        string query = "UPDATE Trainer SET status = 'accepted' WHERE username = @username";
                        SqlCommand cmd = new SqlCommand(query, conn, transaction);
                        cmd.Parameters.AddWithValue("@username", username);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            transaction.Commit();
                            MessageBox.Show("Trainer approved successfully!");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Trainer not found!");
                            transaction.Rollback();
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Trainer username cannot be empty!");
            }
        }

        private void button3_Click(object sender, EventArgs e) //reject
        {
            string username = textBox1.Text;

            if (!string.IsNullOrEmpty(username))
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;"))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        string ownerQuery = "DELETE FROM Trainer WHERE username = @username";
                        SqlCommand ownerCmd = new SqlCommand(ownerQuery, conn, transaction);
                        ownerCmd.Parameters.AddWithValue("@username", username);
                        ownerCmd.ExecuteNonQuery();

                        string traQuery = "DELETE FROM TrainerGym WHERE trainer_username = @username";
                        SqlCommand gymCmd = new SqlCommand(traQuery, conn, transaction);
                        gymCmd.Parameters.AddWithValue("@username", username);
                        gymCmd.ExecuteNonQuery();

                        transaction.Commit();
                        MessageBox.Show("Trainer and associated records removed successfully!");
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Error while updating database: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Trainer username cannot be empty!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            welcome owner = new welcome();
            owner.ShowDialog();
        }
    }
}
