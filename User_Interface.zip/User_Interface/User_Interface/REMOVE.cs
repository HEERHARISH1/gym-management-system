﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace User_Interface
{
    public partial class REMOVE : Form
    {
        public REMOVE()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            try
            {

                {
                    SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;");
                    conn.Open();
                    string query = "SELECT username, status FROM MemberTable where status ='pending'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    var ds = new DataSet();
                    sda.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e) //approve
        {
            string username = textBox1.Text;

            if (!string.IsNullOrEmpty(username))
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;"))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        string query = "UPDATE MemberTable SET status = 'accepted' WHERE username = @username";
                        SqlCommand cmd = new SqlCommand(query, conn, transaction);
                        cmd.Parameters.AddWithValue("@username", username);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            transaction.Commit();
                            MessageBox.Show("MemberTable approved successfully!");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("MemberTable not found!");
                            transaction.Rollback();
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("MemberTable username cannot be empty!");
            }
        }

        private void button3_Click(object sender, EventArgs e) //reject
        {
            string username = textBox1.Text;

            if (!string.IsNullOrEmpty(username))
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-46RCPED\\SQLEXPRESS;Initial Catalog=ProjectFinal5;Integrated Security=True;"))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        string ownerQuery = "DELETE FROM MemberTable WHERE username = @username";
                        SqlCommand ownerCmd = new SqlCommand(ownerQuery, conn, transaction);
                        ownerCmd.Parameters.AddWithValue("@username", username);
                        ownerCmd.ExecuteNonQuery();

                        transaction.Commit();
                        MessageBox.Show("MemberTable removed successfully!");
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Error while updating database: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("MemberTable username cannot be empty!");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            welcome owner = new welcome();
            owner.ShowDialog();
            owner.ShowDialog();
        }

    }
}
